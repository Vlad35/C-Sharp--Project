﻿using Npgsql;
using System;
using System.Windows.Forms;

namespace RAD
{
    public partial class AddIssuance : Form
    {
        private NpgsqlConnection oCon;
        private string connection;

        public AddIssuance(NpgsqlConnection oCon, string connection)
        {
            InitializeComponent();
            this.oCon = oCon;
            this.connection = connection;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int id_worker = int.Parse(textBoxWorkerID.Text);
                DateTime date = dateTimePickerDate.Value;
                decimal sum = decimal.Parse(textBoxSum.Text);

                using (NpgsqlConnection connection = new NpgsqlConnection(this.connection))
                {
                    connection.Open();

                    string query = "INSERT INTO Issuance (id_worker, date, sum) VALUES (@id_worker, @date, @sum)";

                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id_worker", id_worker);
                        command.Parameters.AddWithValue("@date", date);
                        command.Parameters.AddWithValue("@sum", sum);
                        command.ExecuteNonQuery();

                        MessageBox.Show("Данные успешно добавлены в таблицу Issuance.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при добавлении данных: " + ex.Message);
            }
        }
    }
}
