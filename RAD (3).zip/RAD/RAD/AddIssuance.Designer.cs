﻿namespace RAD
{
    partial class AddIssuance
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            textBoxWorkerID = new TextBox();
            textBoxSum = new TextBox();
            button1 = new Button();
            dateTimePickerDate = new DateTimePicker();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Italic, GraphicsUnit.Point);
            label1.Location = new Point(498, 86);
            label1.Name = "label1";
            label1.Size = new Size(212, 41);
            label1.TabIndex = 0;
            label1.Text = "Новая Выдача";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(364, 190);
            label2.Name = "label2";
            label2.Size = new Size(164, 31);
            label2.TabIndex = 1;
            label2.Text = "ID-Работника";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point);
            label3.Location = new Point(454, 262);
            label3.Name = "label3";
            label3.Size = new Size(74, 31);
            label3.TabIndex = 2;
            label3.Text = "Дата";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point);
            label4.Location = new Point(444, 332);
            label4.Name = "label4";
            label4.Size = new Size(84, 31);
            label4.TabIndex = 3;
            label4.Text = "Сумма";
            // 
            // textBoxWorkerID
            // 
            textBoxWorkerID.Location = new Point(650, 196);
            textBoxWorkerID.Name = "textBoxWorkerID";
            textBoxWorkerID.Size = new Size(250, 27);
            textBoxWorkerID.TabIndex = 4;
            // 
            // textBoxSum
            // 
            textBoxSum.Location = new Point(650, 336);
            textBoxSum.Name = "textBoxSum";
            textBoxSum.Size = new Size(250, 27);
            textBoxSum.TabIndex = 6;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 16.2F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(511, 418);
            button1.Name = "button1";
            button1.Size = new Size(171, 45);
            button1.TabIndex = 7;
            button1.Text = "Добавить";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // dateTimePickerDate
            // 
            dateTimePickerDate.Location = new Point(650, 266);
            dateTimePickerDate.Name = "dateTimePickerDate";
            dateTimePickerDate.Size = new Size(250, 27);
            dateTimePickerDate.TabIndex = 8;
            // 
            // AddIssuance
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1193, 585);
            Controls.Add(dateTimePickerDate);
            Controls.Add(button1);
            Controls.Add(textBoxSum);
            Controls.Add(textBoxWorkerID);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "AddIssuance";
            Text = "AddIssuance";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox textBoxWorkerID;
        private TextBox textBoxSum;
        private Button button1;
        private DateTimePicker dateTimePickerDate;
    }
}