﻿using Npgsql;
using System;
using System.Windows.Forms;

namespace RAD
{
    public partial class DeleteIssuance : Form
    {
        private NpgsqlConnection oCon;
        private string connection;

        public DeleteIssuance(NpgsqlConnection oCon, string connection)
        {
            InitializeComponent();
            this.oCon = oCon;
            this.connection = connection;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int id = int.Parse(textBox1.Text);

                using (NpgsqlConnection connection = new NpgsqlConnection(this.connection))
                {
                    connection.Open();

                    string query = "DELETE FROM Issuance WHERE id = @id";

                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        command.ExecuteNonQuery();

                        MessageBox.Show("Запись успешно удалена.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при удалении записи: " + ex.Message);
            }
        }
    }
}
