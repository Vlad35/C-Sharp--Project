﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RAD
{
    public partial class Form5 : Form
    {
        public NpgsqlConnection oCon;
        public string SQL;
        public string connection;
        public int supplier_id;
        public Form5(NpgsqlConnection oCon, string connection)
        {
            InitializeComponent();
            this.oCon = oCon;
            this.connection = connection;
            this.UpdateGrid();
        }
        public void UpdateGrid()
        {
            try
            {
                // Создайте подключение к базе данных
                using (NpgsqlConnection connection = new NpgsqlConnection(this.connection))
                {
                    // Откройте подключение
                    connection.Open();

                    // Создайте команду для выполнения запроса SELECT
                    string query = "SELECT id, ArticleID, Amount, Sum FROM Orders";
                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        // Создайте объект для чтения результатов запроса
                        using (NpgsqlDataReader reader = command.ExecuteReader())
                        {
                            // Очистите существующие строки в DataGridView
                            dataGridView1.Rows.Clear();

                            // Прочитайте результаты запроса и добавьте их в таблицу DataGridView
                            while (reader.Read())
                            {
                                // Получите значения столбцов
                                int id = reader.GetInt32(0);
                                int articleId = reader.GetInt32(1);
                                int amount = reader.GetInt32(2);
                                decimal sum = reader.GetDecimal(3);

                                // Добавьте значения в DataGridView
                                dataGridView1.Rows.Add(id, articleId, amount, sum);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Обработайте возможные ошибки подключения к базе данных
                MessageBox.Show("Ошибка при получении данных: " + ex.Message);
            }
        }

        public Form5()
        {
            InitializeComponent();
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
