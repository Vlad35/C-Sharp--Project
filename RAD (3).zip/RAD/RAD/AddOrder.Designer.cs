﻿namespace RAD
{
    partial class AddOrder
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label4 = new Label();
            label5 = new Label();
            button1 = new Button();
            textBoxArticleId = new TextBox();
            textBoxAmount = new TextBox();
            textBoxSum = new TextBox();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Italic, GraphicsUnit.Point);
            label1.Location = new Point(595, 101);
            label1.Name = "label1";
            label1.Size = new Size(192, 41);
            label1.TabIndex = 0;
            label1.Text = "Новый Заказ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(429, 224);
            label2.Name = "label2";
            label2.Size = new Size(137, 31);
            label2.TabIndex = 1;
            label2.Text = "ID-Статьи";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point);
            label4.Location = new Point(424, 296);
            label4.Name = "label4";
            label4.Size = new Size(142, 31);
            label4.TabIndex = 3;
            label4.Text = "Количество";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point);
            label5.Location = new Point(482, 357);
            label5.Name = "label5";
            label5.Size = new Size(84, 31);
            label5.TabIndex = 4;
            label5.Text = "Сумма";
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(595, 424);
            button1.Name = "button1";
            button1.Size = new Size(155, 42);
            button1.TabIndex = 5;
            button1.Text = "Добавить";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBoxArticleId
            // 
            textBoxArticleId.Location = new Point(749, 228);
            textBoxArticleId.Name = "textBoxArticleId";
            textBoxArticleId.Size = new Size(301, 27);
            textBoxArticleId.TabIndex = 6;
            // 
            // textBoxAmount
            // 
            textBoxAmount.Location = new Point(749, 296);
            textBoxAmount.Name = "textBoxAmount";
            textBoxAmount.Size = new Size(301, 27);
            textBoxAmount.TabIndex = 8;
            // 
            // textBoxSum
            // 
            textBoxSum.Location = new Point(749, 357);
            textBoxSum.Name = "textBoxSum";
            textBoxSum.Size = new Size(301, 27);
            textBoxSum.TabIndex = 9;
            // 
            // AddOrder
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1344, 644);
            Controls.Add(textBoxSum);
            Controls.Add(textBoxAmount);
            Controls.Add(textBoxArticleId);
            Controls.Add(button1);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "AddOrder";
            Text = "AddOrder";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label4;
        private Label label5;
        private Button button1;
        private TextBox textBoxArticleId;
        private TextBox textBoxAmount;
        private TextBox textBoxSum;
    }
}