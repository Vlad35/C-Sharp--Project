﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;

namespace RAD
{
    public partial class Form2 : Form
    {
        public NpgsqlConnection oCon;
        public string SQL;
        public string connection;
        public int supplier_id;
        public Form2(NpgsqlConnection oCon, string connection)
        {
            InitializeComponent();
            this.oCon = oCon;
            this.connection = connection;
            this.UpdateGrid();
        }
        public Form2()
        {
            InitializeComponent();
        }
        public void UpdateGrid()
        {
            try
            {
                // Создайте подключение к базе данных
                using (NpgsqlConnection connection = new NpgsqlConnection(this.connection))
                {
                    // Откройте подключение
                    connection.Open();

                    // Создайте команду для выполнения запроса SELECT
                    string query = "SELECT id, FIO, Phone FROM Workers";
                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        // Создайте объект для чтения результатов запроса
                        using (NpgsqlDataReader reader = command.ExecuteReader())
                        {
                            // Очистите существующие строки в DataGridView
                            dataGridView1.Rows.Clear();

                            // Прочитайте результаты запроса и добавьте их в таблицу DataGridView
                            while (reader.Read())
                            {
                                // Получите значения столбцов
                                int id = reader.GetInt32(0);
                                string fio = reader.GetString(1);
                                string phone = reader.GetString(2);

                                // Добавьте значения в DataGridView
                                dataGridView1.Rows.Add(id, fio, phone);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Обработайте возможные ошибки подключения к базе данных
                MessageBox.Show("Ошибка при получении данных: " + ex.Message);
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
