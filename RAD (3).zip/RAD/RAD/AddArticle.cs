﻿using Npgsql;
using System;
using System.Windows.Forms;

namespace RAD
{
    public partial class AddArticle : Form
    {
        private NpgsqlConnection oCon;
        private string connection;

        public AddArticle(NpgsqlConnection oCon, string connection)
        {
            InitializeComponent();
            this.oCon = oCon;
            this.connection = connection;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string title = textBoxTitle.Text;

                using (NpgsqlConnection connection = new NpgsqlConnection(this.connection))
                {
                    connection.Open();

                    string query = "INSERT INTO Articles (Title) VALUES (@title)";

                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@title", title);
                        command.ExecuteNonQuery();

                        MessageBox.Show("Данные успешно добавлены в таблицу Articles.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при добавлении данных: " + ex.Message);
            }
        }
    }
}
