﻿namespace RAD
{
    partial class AddReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            textBoxOrderId = new TextBox();
            textBoxWorkerId = new TextBox();
            textBoxIssuanceId = new TextBox();
            textBoxSum = new TextBox();
            textBoxAmount = new TextBox();
            button1 = new Button();
            DateTimePicker = new DateTimePicker();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 18F, FontStyle.Italic, GraphicsUnit.Point);
            label1.Location = new Point(609, 60);
            label1.Name = "label1";
            label1.Size = new Size(215, 41);
            label1.TabIndex = 0;
            label1.Text = "Новый отчет";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(524, 145);
            label2.Name = "label2";
            label2.Size = new Size(111, 31);
            label2.TabIndex = 1;
            label2.Text = "ID Заказа";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point);
            label3.Location = new Point(475, 190);
            label3.Name = "label3";
            label3.Size = new Size(160, 31);
            label3.TabIndex = 2;
            label3.Text = "ID работника";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point);
            label4.Location = new Point(515, 243);
            label4.Name = "label4";
            label4.Size = new Size(120, 31);
            label4.TabIndex = 3;
            label4.Text = "ID выдачи";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point);
            label5.Location = new Point(551, 296);
            label5.Name = "label5";
            label5.Size = new Size(84, 31);
            label5.TabIndex = 4;
            label5.Text = "Сумма";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point);
            label6.Location = new Point(493, 356);
            label6.Name = "label6";
            label6.Size = new Size(142, 31);
            label6.TabIndex = 5;
            label6.Text = "Количество";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 13.8F, FontStyle.Italic, GraphicsUnit.Point);
            label7.Location = new Point(561, 416);
            label7.Name = "label7";
            label7.Size = new Size(74, 31);
            label7.TabIndex = 6;
            label7.Text = "Дата";
            // 
            // textBoxOrderId
            // 
            textBoxOrderId.Location = new Point(746, 145);
            textBoxOrderId.Name = "textBoxOrderId";
            textBoxOrderId.Size = new Size(263, 27);
            textBoxOrderId.TabIndex = 7;
            // 
            // textBoxWorkerId
            // 
            textBoxWorkerId.Location = new Point(746, 194);
            textBoxWorkerId.Name = "textBoxWorkerId";
            textBoxWorkerId.Size = new Size(263, 27);
            textBoxWorkerId.TabIndex = 8;
            // 
            // textBoxIssuanceId
            // 
            textBoxIssuanceId.Location = new Point(746, 249);
            textBoxIssuanceId.Name = "textBoxIssuanceId";
            textBoxIssuanceId.Size = new Size(263, 27);
            textBoxIssuanceId.TabIndex = 9;
            // 
            // textBoxSum
            // 
            textBoxSum.Location = new Point(746, 302);
            textBoxSum.Name = "textBoxSum";
            textBoxSum.Size = new Size(263, 27);
            textBoxSum.TabIndex = 10;
            // 
            // textBoxAmount
            // 
            textBoxAmount.Location = new Point(746, 356);
            textBoxAmount.Name = "textBoxAmount";
            textBoxAmount.Size = new Size(263, 27);
            textBoxAmount.TabIndex = 11;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            button1.Location = new Point(587, 481);
            button1.Name = "button1";
            button1.Size = new Size(224, 38);
            button1.TabIndex = 13;
            button1.Text = "Добавить";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // DateTimePicker
            // 
            DateTimePicker.Location = new Point(746, 420);
            DateTimePicker.Name = "DateTimePicker";
            DateTimePicker.Size = new Size(263, 27);
            DateTimePicker.TabIndex = 14;
            // 
            // AddReport
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1277, 625);
            Controls.Add(DateTimePicker);
            Controls.Add(button1);
            Controls.Add(textBoxAmount);
            Controls.Add(textBoxSum);
            Controls.Add(textBoxIssuanceId);
            Controls.Add(textBoxWorkerId);
            Controls.Add(textBoxOrderId);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "AddReport";
            Text = "AddReport";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private TextBox textBoxOrderId;
        private TextBox textBoxWorkerId;
        private TextBox textBoxIssuanceId;
        private TextBox textBoxSum;
        private TextBox textBoxAmount;
        private Button button1;
        private DateTimePicker DateTimePicker;
    }
}