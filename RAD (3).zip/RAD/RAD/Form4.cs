﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RAD
{
    public partial class Form4 : Form
    {
        public NpgsqlConnection oCon;
        public string SQL;
        public string connection;
        public int supplier_id;
        public Form4(NpgsqlConnection oCon, string connection)
        {
            InitializeComponent();
            this.oCon = oCon;
            this.connection = connection;
            this.UpdateGrid();
        }
        public void UpdateGrid()
        {
            try
            {
                // Создайте подключение к базе данных
                using (NpgsqlConnection connection = new NpgsqlConnection(this.connection))
                {
                    // Откройте подключение
                    connection.Open();

                    // Создайте команду для выполнения запроса SELECT
                    string query = "SELECT id, id_worker, date, sum FROM Issuance";
                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        // Создайте объект для чтения результатов запроса
                        using (NpgsqlDataReader reader = command.ExecuteReader())
                        {
                            // Очистите существующие строки в DataGridView
                            dataGridView1.Rows.Clear();

                            // Прочитайте результаты запроса и добавьте их в таблицу DataGridView
                            while (reader.Read())
                            {
                                // Получите значения столбцов
                                int id = reader.GetInt32(0);
                                int idWorker = reader.GetInt32(1);
                                DateTime date = reader.GetDateTime(2);
                                decimal sum = reader.GetDecimal(3);

                                // Добавьте значения в DataGridView
                                dataGridView1.Rows.Add(id, idWorker, date, sum);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Обработайте возможные ошибки подключения к базе данных
                MessageBox.Show("Ошибка при получении данных: " + ex.Message);
            }
        }

        public Form4()
        {
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }
    }
}
