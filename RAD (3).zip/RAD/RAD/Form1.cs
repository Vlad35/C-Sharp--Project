﻿using Npgsql;
using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using OfficeOpenXml;
using System.IO;

namespace RAD
{
    public partial class Form1 : Form
    {
        public NpgsqlConnection oCon;
        public string connection;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection = "Server=localhost; Port=5432; User Id=postgres; Password=28012004; Database=RAD-Postgre;";
            oCon = new NpgsqlConnection(connection);
            Form2 form2 = new Form2(oCon, connection);
            form2.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            connection = "Server=localhost; Port=5432; User Id=postgres; Password=28012004; Database=RAD-Postgre;";
            oCon = new NpgsqlConnection(connection);
            Form3 form3 = new Form3(oCon, connection);
            form3.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            connection = "Server=localhost; Port=5432; User Id=postgres; Password=28012004; Database=RAD-Postgre;";
            oCon = new NpgsqlConnection(connection);
            Form4 form4 = new Form4(oCon, connection);
            form4.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            connection = "Server=localhost; Port=5432; User Id=postgres; Password=28012004; Database=RAD-Postgre;";
            oCon = new NpgsqlConnection(connection);
            Form5 form5 = new Form5(oCon, connection);
            form5.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            connection = "Server=localhost; Port=5432; User Id=postgres; Password=28012004; Database=RAD-Postgre;";
            oCon = new NpgsqlConnection(connection);
            Form6 form6 = new Form6(oCon, connection);
            form6.Show();
        }

        private void Добавить_Click(object sender, EventArgs e)
        {
            connection = "Server=localhost; Port=5432; User Id=postgres; Password=28012004; Database=RAD-Postgre;";
            oCon = new NpgsqlConnection(connection);
            AddOrder form = new AddOrder(oCon, connection);
            form.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            connection = "Server=localhost; Port=5432; User Id=postgres; Password=28012004; Database=RAD-Postgre;";
            oCon = new NpgsqlConnection(connection);
            DeleteOrder form = new DeleteOrder(oCon, connection);
            form.Show();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            connection = "Server=localhost; Port=5432; User Id=postgres; Password=28012004; Database=RAD-Postgre;";
            oCon = new NpgsqlConnection(connection);
            AddIssuance form = new AddIssuance(oCon, connection);
            form.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            connection = "Server=localhost; Port=5432; User Id=postgres; Password=28012004; Database=RAD-Postgre;";
            oCon = new NpgsqlConnection(connection);
            DeleteIssuance form = new DeleteIssuance(oCon, connection);
            form.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            connection = "Server=localhost; Port=5432; User Id=postgres; Password=28012004; Database=RAD-Postgre;";
            oCon = new NpgsqlConnection(connection);
            AddReport form = new AddReport(oCon, connection);
            form.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            connection = "Server=localhost; Port=5432; User Id=postgres; Password=28012004; Database=RAD-Postgre;";
            oCon = new NpgsqlConnection(connection);
            DeleteReport form = new DeleteReport(oCon, connection);
            form.Show();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            connection = "Server=localhost; Port=5432; User Id=postgres; Password=28012004; Database=RAD-Postgre;";
            oCon = new NpgsqlConnection(connection);
            AddArticle form = new AddArticle(oCon, connection);
            form.Show();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            connection = "Server=localhost; Port=5432; User Id=postgres; Password=28012004; Database=RAD-Postgre;";
            oCon = new NpgsqlConnection(connection);
            DeleteArticle form = new DeleteArticle(oCon, connection);
            form.Show();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            connection = "Server=localhost; Port=5432; User Id=postgres; Password=28012004; Database=RAD-Postgre;";
            oCon = new NpgsqlConnection(connection);
            AddWorker form = new AddWorker(oCon, connection);
            form.Show();
        }

        private void button14_Click(object sender, EventArgs e)
        {
            connection = "Server=localhost; Port=5432; User Id=postgres; Password=28012004; Database=RAD-Postgre;";
            oCon = new NpgsqlConnection(connection);
            DeleteWorker form = new DeleteWorker(oCon, connection);
            form.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            connection = "Server=localhost; Port=5432; User Id=postgres; Password=28012004; Database=RAD-Postgre;";
            oCon = new NpgsqlConnection(connection);
            ExportReportsToExcel();
        }

        private void ExportReportsToExcel()
        {
            try
            {
                // Set the LicenseContext for EPPlus
                ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

                // Create a new DataTable to store the data from the Reports table
                DataTable reportsTable = new DataTable();

                using (NpgsqlDataAdapter adapter = new NpgsqlDataAdapter("SELECT * FROM Report", oCon))
                {
                    adapter.Fill(reportsTable);
                }

                if (reportsTable.Rows.Count > 0)
                {
                    using (ExcelPackage excelPackage = new ExcelPackage())
                    {
                        ExcelWorksheet worksheet = excelPackage.Workbook.Worksheets.Add("Reports");

                        // Fill the worksheet with data
                        worksheet.Cells["A1"].LoadFromDataTable(reportsTable, true);

                        // Set the date format for the "date" column
                        var dateColumn = worksheet.Cells["F:F"];
                        dateColumn.Style.Numberformat.Format = "yyyy-mm-dd";

                        // Save the Excel file
                        string filePath = @"D:\Reports.xlsx";
                        FileInfo file = new FileInfo(filePath);
                        excelPackage.SaveAs(file);
                    }

                    MessageBox.Show("Data exported to Excel successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("No data found in the Reports table.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while exporting data to Excel: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
