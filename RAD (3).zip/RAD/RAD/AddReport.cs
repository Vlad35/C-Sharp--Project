﻿using Npgsql;
using System;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace RAD
{
    public partial class AddReport : Form
    {
        private NpgsqlConnection oCon;
        private string connection;

        public AddReport(NpgsqlConnection oCon, string connection)
        {
            InitializeComponent();
            this.oCon = oCon;
            this.connection = connection;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int orderId = int.Parse(textBoxOrderId.Text);
                int workerId = int.Parse(textBoxWorkerId.Text);
                int issuanceId = int.Parse(textBoxIssuanceId.Text);
                decimal amount = decimal.Parse(textBoxAmount.Text);
                DateTime date = DateTimePicker.Value;
                decimal sum = decimal.Parse(textBoxSum.Text);

                using (NpgsqlConnection connection = new NpgsqlConnection(this.connection))
                {
                    connection.Open();

                    string query = "INSERT INTO Report (OrderId, WorkerId, IssuanceId, Amount, Date, Sum) " +
                        "VALUES (@orderId, @workerId, @issuanceId, @amount, @date, @sum)";

                    using (NpgsqlCommand command = new NpgsqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@orderId", orderId);
                        command.Parameters.AddWithValue("@workerId", workerId);
                        command.Parameters.AddWithValue("@issuanceId", issuanceId);
                        command.Parameters.AddWithValue("@amount", amount);
                        command.Parameters.AddWithValue("@date", date);
                        command.Parameters.AddWithValue("@sum", sum);
                        command.ExecuteNonQuery();

                        MessageBox.Show("Данные успешно добавлены в таблицу Report.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при добавлении данных: " + ex.Message);
            }
        }
    }
}
